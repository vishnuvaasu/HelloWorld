//
//  MockSignInViewModel.swift
//  SampleUnitTestAppTests
//
//  Created by Gowri Karthik on 05/06/21.
//

import Foundation
@testable import SampleUnitTestApp

class MockSignInViewModel: SignInViewModelProtocol {
    var isUserLogIn: Bool?
    var isSignInMethodCalled = false
    
    required init(delegate: SignViewModelDelegate, signInValidator: SignInValidatorProtocol) {
        
    }
    
    func signIn(email: String, password: String) {
        isSignInMethodCalled = true
    }
    
    func isUserLoggedIn() -> Bool {
        return isUserLogIn ?? false
    }
}
