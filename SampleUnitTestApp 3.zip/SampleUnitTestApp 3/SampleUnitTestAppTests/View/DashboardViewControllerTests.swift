//
//  DashboardViewControllerTests.swift
//  SampleUnitTestAppTests
//
//  Created by Gowri Karthik on 06/06/21.
//

import XCTest
@testable import SampleUnitTestApp

class DashboardViewControllerTests: XCTestCase {

    var storyboard: UIStoryboard!
    var sut: DashboardViewController!
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        storyboard = UIStoryboard(name: Constants.mainStoryboard, bundle: nil)
        sut = storyboard.instantiateViewController(withIdentifier: Constants.dashboardViewController) as? DashboardViewController
        sut.loadViewIfNeeded()
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    
    // testDashboardViewController_WhenCreated_collectionViewSetupIsConfigured
    func testCollectionViewSetupIsConfigured() throws {
        let collectionView = try XCTUnwrap(sut.videosCollectionView, "VideoCollectionView is not connected to a outlet")
        let _ = try XCTUnwrap(collectionView.delegate, "Delegate for the videoCollectionView is not set")
        let _ = try XCTUnwrap(collectionView.dataSource, "DataSource for the videoCollectionView is not set")
    }

}
