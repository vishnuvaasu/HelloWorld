//
//  BaseNetworkServiceTests.swift
//  SampleUnitTestAppTests
//
//  Created by Gowri Karthik on 06/06/21.
//

import XCTest
@testable import SampleUnitTestApp
import Alamofire
import SwiftyJSON

class BaseNetworkServiceTests: XCTestCase {
    
    var sut: BaseService!
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [MockURLProtocol.self]
        let urlSession = URLSession(configuration: config)
        
        sut = BaseService(urlSession: urlSession)
    }
    
    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        sut = nil
    }
    
    // testBaseNetworkService_WhenGivenSuccessfullResponse_ReturnsSuccessJSON
    func testWhenGivenSuccessfullResponse() throws {
        let jsonString = "{\"status\":\"ok\"}"
        MockURLProtocol.stubResponseData =  jsonString.data(using: .utf8)
        MockURLProtocol.error = nil

        
        let expectation = self.expectation(description: "BaseService Response Expectation")
        
        sut.request(method: .get) { (error, data) in
            if data != nil {
                expectation.fulfill()
            }
        }
        
        wait(for: [expectation], timeout: 2)
    }
    
    // testBaseNetworkService_WhenGivenFailedResponse_ReturnErrorMessage
    func testWhenGivenFailedResponse() {
        MockURLProtocol.error = NetworkError.failedRequest(description: "Request Failed for Unit Test")
        MockURLProtocol.stubResponseData = nil
        
        let expectation = self.expectation(description: "BaseService Response Expectation")

        sut.request(method: .get) { (error, data) in
            if error != nil {
                expectation.fulfill()
            }
        }

        wait(for: [expectation], timeout: 2)
    }
    
}
