//
//  VideoSubCollectionViewCell.swift
//  LazyLoadingWithTestCase
//
//  Created by Gowri Karthik on 28/05/21.
//

import UIKit

class VideoSubCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var videoImageView: AsyncImageView!
    @IBOutlet weak var movieName: UILabel!
    @IBOutlet weak var deleteButton: UIButton!
    @IBOutlet weak var blurView:UIView!
    
    var representedIdentifier: String = ""
    
    var image: UIImage? {
        didSet {
            videoImageView.image = image
        }
      }
    
    var onDelete: (()-> Void)?
    override func awakeFromNib() {
        super.awakeFromNib()
        
        videoImageView.layer.cornerRadius = 10
        videoImageView.layer.shadowRadius = 2
        videoImageView.layer.shadowOpacity = 0.2
        videoImageView.layer.borderWidth = 0.5
        videoImageView.layer.borderColor = UIColor.lightGray.cgColor
        blurView.layer.cornerRadius = 10
        videoImageView.layer.shadowRadius = 2
        videoImageView.layer.shadowOpacity = 0.2
        videoImageView.layer.borderWidth = 0.5
        videoImageView.layer.borderColor = UIColor.white.cgColor
    }

    @IBAction func deleteClick(_ sender: UIButton) {
        onDelete?()
    }
}
