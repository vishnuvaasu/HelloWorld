//
//  SignInViewController.swift
//  SampleUnitTestApp
//
//  Created by Gowri Karthik on 04/06/21.
//

import UIKit

class SignInViewController: UIViewController {
    
    @IBOutlet weak var logoImageView: UIImageView!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var cardView: UIView!
    
    var viewModel: SignInViewModelProtocol!

    override func viewDidLoad() {
        super.viewDidLoad()
        if viewModel == nil {
            viewModel = SignInViewModel(delegate: self, signInValidator: SignInValidator())
        }
        displayUI()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if viewModel.isUserLoggedIn() {
            goToDashboard()
        }
    }
    
    @IBAction func loginClick(_ sender: UIButton) {
        viewModel.signIn(email: emailTextField.text ?? "", password: passwordTextField.text ?? "")
    }
    
}

extension SignInViewController: SignViewModelDelegate {
    
    func onErrorReceived(error: SignInError) {
        let alertController = UIAlertController(title: Constants.login, message: error.localizedDescription, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: Constants.ok, style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
    
    func onSuccessfullSignIn() {
        emailTextField.text = ""
        passwordTextField.text = ""
        view.endEditing(true)
        goToDashboard()
    }
}

extension SignInViewController {
    
    func goToDashboard() {        
        let navBar = UIStoryboard(name: Constants.mainStoryboard, bundle: nil).instantiateViewController(withIdentifier: Constants.dashboardNavigationController)
        navBar.modalTransitionStyle = .crossDissolve
        navBar.modalPresentationStyle = .overFullScreen
        present(navBar, animated: true, completion: nil)
    }
    
    func displayUI() {
        logoImageView.layer.cornerRadius = logoImageView.frame.size.width/2
        logoImageView.layer.borderWidth = 2.0
        logoImageView.layer.borderColor = UIColor.black.cgColor
        logoImageView.layer.shadowOpacity = 0.2
        logoImageView.layer.shadowRadius = 2.0
        
        loginButton.layer.cornerRadius = 5
        loginButton.layer.shadowRadius = 2.0
        loginButton.layer.shadowOpacity = 0.2
        
        cardView.layer.cornerRadius = 10
        cardView.layer.shadowRadius = 2.0
        cardView.layer.shadowOpacity = 0.2
    }
}
