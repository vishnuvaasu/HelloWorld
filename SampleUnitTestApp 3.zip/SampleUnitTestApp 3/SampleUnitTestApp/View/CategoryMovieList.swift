//
//  CategoryMovieListViewController.swift
//  LazyLoadingWithTestCase
//
//  Created by Gowri Karthik on 01/06/21.
//

import UIKit

class CategoryMovieListViewController: UIViewController {

    @IBOutlet weak var myListCollectionView: UICollectionView!
    
    var index = 0
    var categoryName = ""
    var videos: [Movie]?
    var viewModel = HomeViewModel()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        myListCollectionView.register(UINib(nibName: String(describing: VideoSubCollectionViewCell.self), bundle: nil), forCellWithReuseIdentifier: String(describing: VideoSubCollectionViewCell.self))
        myListCollectionView.contentInset = UIEdgeInsets.init(top: 0, left: 16, bottom: 0, right: 16)
        title = categoryName
    }
    
}

extension CategoryMovieListViewController: UICollectionViewDelegate,UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return videos?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: String(describing: VideoSubCollectionViewCell.self), for: indexPath) as! VideoSubCollectionViewCell
        let video = videos?[indexPath.row]
        cell.movieName.text = video?.name
        cell.image = nil
        let representedIdentifier = video?.videoId ?? ""
        cell.representedIdentifier = representedIdentifier
        viewModel.fetchImage(imageURL: video?.image ?? "") { (img) -> (Void) in
            if (cell.representedIdentifier == representedIdentifier) {
                cell.image = img
            }
        }
        return cell
    }
   
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let video = videos?[indexPath.row]
        let vc = UIStoryboard.init(name: Constants.mainStoryboard, bundle: nil).instantiateViewController(withIdentifier: Constants.movieDetailViewController) as! MovieDetailViewController
        vc.movie = video
        vc.categoryName = categoryName
        navigationController?.pushViewController(vc, animated: true)
    }
    
}

extension CategoryMovieListViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 120 , height: 150)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10.0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10.0
    }
}
