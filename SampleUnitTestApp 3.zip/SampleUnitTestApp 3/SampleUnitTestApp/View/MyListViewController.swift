//
//  MyListViewController.swift
//  SampleUnitTestApp
//
//  Created by Gowri Karthik on 14/06/21.
//

import UIKit

class MyListViewController: UIViewController {

    @IBOutlet weak var myListCollectionView:UICollectionView!
    @IBOutlet weak var noDataLabel: UILabel!
    
  //  let realm = try! Realm()
  //  var movieData: Results<MoviesData>?
    var isEditable = false
    var viewModel = HomeViewModel()
    override func viewDidLoad() {
        super.viewDidLoad()

        let editButton = UIBarButtonItem(title: Constants.edit, style: .done, target: self, action: #selector(editTapped))
            self.navigationItem.rightBarButtonItem  = editButton

        navigationItem.rightBarButtonItem?.tintColor = .white

        myListCollectionView.register(UINib(nibName: String(describing: VideoSubCollectionViewCell.self), bundle: nil), forCellWithReuseIdentifier: String(describing: VideoSubCollectionViewCell.self))
        myListCollectionView.contentInset = UIEdgeInsets.init(top: 0, left: 16, bottom: 0, right: 16)
        loadData()
    }
    
    func loadData() {
      //  movieData = DatabaseManager.shared.fetch(object: MoviesData.self)
        myListCollectionView.reloadData()
      //  noDataLabel.isHidden = (movieData?.count == 0) ? false : true
    }
    
    @objc func editTapped(_ sender: UIBarButtonItem) {
        isEditable = !isEditable
        myListCollectionView.reloadData()
        self.navigationItem.rightBarButtonItem?.title = isEditable ? Constants.done : Constants.edit
    }

}

extension MyListViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: Constants.width , height: Constants.height)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return CGFloat(Constants.minMaxSpace)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return CGFloat(Constants.minMaxSpace)
    }
}
