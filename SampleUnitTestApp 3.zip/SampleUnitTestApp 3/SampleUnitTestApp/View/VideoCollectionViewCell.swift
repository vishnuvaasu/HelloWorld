//
//  VideoCollectionViewCell.swift
//  LazyLoadingWithTestCase
//
//  Created by Gowri Karthik on 28/05/21.
//

import UIKit

class VideoCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var videoSubCollectionView: UICollectionView!
    @IBOutlet weak var categoryButton: UIButton!
    
    var categoryClick: ((_ tag: Int) -> Void)?

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        videoSubCollectionView.register(UINib(nibName: String(describing: VideoSubCollectionViewCell.self), bundle: nil), forCellWithReuseIdentifier: String(describing: VideoSubCollectionViewCell.self))
        videoSubCollectionView.contentInset = UIEdgeInsets.init(top: 0, left: 16, bottom: 0, right: 16)
    }
    
    @IBAction func categoryClick(_ sender: UIButton) {
        categoryClick?(sender.tag)
    }

}
