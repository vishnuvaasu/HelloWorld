//
//  DashboardViewController.swift
//  SampleUnitTestApp
//
//  Created by Gowri Karthik on 06/06/21.
//

import UIKit

class DashboardViewController: UIViewController {
    
    @IBOutlet weak var videosCollectionView: UICollectionView!
    @IBOutlet weak var logoutBarButton: UIBarButtonItem!
    
    private let viewModel = HomeViewModel()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        videosCollectionView.register(UINib(nibName: String(describing: VideoCollectionViewCell.self), bundle: nil), forCellWithReuseIdentifier: String(describing: VideoCollectionViewCell.self))
        peformAPICallToFetchDetails()
    }
    
    
    private func peformAPICallToFetchDetails() {
        self.viewModel.fetchMovies { (error, movies) in
            if movies?.isEmpty == false {
                self.videosCollectionView.reloadData()
            } else {
                let alertController = UIAlertController(title: Constants.videos, message: error, preferredStyle: .alert)
                alertController.addAction(UIAlertAction(title: Constants.ok, style: .default, handler: nil))
                self.present(alertController, animated: true, completion: nil)
            }
        }
    }

    @IBAction func logoutClick(_ sender: UIBarButtonItem) {
        UserDefaults.standard.setValue(false, forKey: Constants.userLoginStatus)
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func myListClick(_ sender: UIBarButtonItem) {
        let vc = UIStoryboard.init(name: Constants.mainStoryboard, bundle: nil).instantiateViewController(withIdentifier: Constants.myListViewController) as! MyListViewController
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension DashboardViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == videosCollectionView {
            return viewModel.noOfCategories
        } else {
            let videos = viewModel.getMovieCategory(index: collectionView.tag)?.movies ?? []
            return videos.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == videosCollectionView {
           
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: String(describing: VideoCollectionViewCell.self), for: indexPath) as! VideoCollectionViewCell
                cell.videoSubCollectionView.delegate = self
                cell.videoSubCollectionView.dataSource = self
              //  cell.videoSubCollectionView.prefetchDataSource = self
                cell.videoSubCollectionView.tag = indexPath.row
                if let category = viewModel.getMovieCategory(index: indexPath.row) {
                    cell.categoryButton.setTitle(category.name ?? "", for: .normal)
                    
                    cell.categoryClick = {[weak self] (tag) in
                        let vc = UIStoryboard.init(name: Constants.mainStoryboard, bundle: nil).instantiateViewController(withIdentifier: Constants.categoryMovieListViewController) as! CategoryMovieListViewController
                        vc.index = indexPath.row
                        vc.videos = category.movies
                        vc.categoryName = category.name ?? ""
                        self?.navigationController?.pushViewController(vc, animated: true)
                    }
                }
                
                cell.videoSubCollectionView.reloadData()
                return cell
            
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: String(describing: VideoSubCollectionViewCell.self), for: indexPath)
                as! VideoSubCollectionViewCell
            if let videos = viewModel.getMovieCategory(index: collectionView.tag)?.movies {
                let video = videos[indexPath.row]
                
                cell.movieName.text = video.name
                
                cell.image = nil
                let representedIdentifier = video.videoId
                cell.representedIdentifier = representedIdentifier ?? ""
                viewModel.fetchImage(imageURL: video.image ?? "") { (img) -> (Void) in
                    if (cell.representedIdentifier == representedIdentifier) {
                        cell.image = img
                    }
                }
            }
            return cell
        }
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == videosCollectionView {
            
        } else {
            if let videos = viewModel.getMovieCategory(index: collectionView.tag)?.movies {
                
                let video = videos[indexPath.row]
                let vc = UIStoryboard.init(name: Constants.mainStoryboard, bundle: nil).instantiateViewController(withIdentifier: Constants.movieDetailViewController) as! MovieDetailViewController
                vc.movie = video
                vc.categoryName = viewModel.getMovieCategory(index: collectionView.tag)?.name ?? ""
                navigationController?.pushViewController(vc, animated: true)
            }
        }
    }
}

//extension DashboardViewController: UICollectionViewDataSourcePrefetching {
//    func collectionView(_ collectionView: UICollectionView, prefetchItemsAt indexPaths: [IndexPath]) {
//        if collectionView != videosCollectionView {
//            print("Prefetching Indexs \(collectionView.tag)", indexPaths)
//            for index in indexPaths {
//                if let videos = viewModel.getMovieCategory(index: collectionView.tag)?.movies {
//                    let video = videos[index.row]
//                    viewModel.fetchImage(imageURL: video.image ?? "") { (img) -> (Void) in
//                    }
//                }
//            }
//        } else {
//            print("Prefetching Indexs Vertical \(collectionView.tag)", indexPaths)
//        }
//    }
//}


extension DashboardViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = collectionView.frame.size.width
        let height = collectionView.frame.size.height
        if collectionView == videosCollectionView {
            if indexPath.row == 0 {
                return CGSize(width: width, height: 250)
            } else {
                return CGSize(width: width, height: 200)
            }
            
        } else {
            return CGSize(width: height - 30 , height: height)
        }
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 5.0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 5.0
    }
}
