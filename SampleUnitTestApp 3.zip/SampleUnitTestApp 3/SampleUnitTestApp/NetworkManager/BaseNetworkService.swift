//
//  BaseNetworkService.swift
//  SampleUnitTestApp
//
//  Created by Gowri Karthik on 06/06/21.
//

import Foundation
import Alamofire
import SwiftyJSON

enum NetworkManagerError: Error {
  case badResponse(URLResponse?)
  case badData
  case badLocalUrl
}

class BaseService {
    
    static let shared = BaseService ()
    private var urlSession: URLSession
    private let baseURL = URL(string: "https://mocki.io/v1/1e8447ea-fe3d-43ad-80cf-fc525f8c5534")!
    
    private var images = NSCache<NSString, NSData>()
    
    init(urlSession: URLSession = .shared) {
        self.urlSession = urlSession
    }
    
    func request(method: HTTPMethod = .post, completionHandler: @escaping (String?, JSON?) -> Void) {
        var request = URLRequest(url: baseURL)
        request.httpMethod = method.rawValue
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let dataTask = urlSession.dataTask(with: request) { (data, response, error) in
            DispatchQueue.main.async {
                if let requestError = error {
                    completionHandler(requestError.localizedDescription , nil)
                    return
                }
                
                if let data = data {
                    completionHandler(nil, JSON(data))
                }
            }
        }
        dataTask.resume()
    }
    
    private func download(imageURL: URL, completion: @escaping (Data?, Error?) -> (Void)) {
        if let imageData = images.object(forKey: imageURL.absoluteString as NSString) {
          print("using cached images")
          completion(imageData as Data, nil)
          return
        }
        
        let task = urlSession.downloadTask(with: imageURL) { localUrl, response, error in
          if let error = error {
            completion(nil, error)
            return
          }
          
          guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
            completion(nil, NetworkManagerError.badResponse(response))
            return
          }
          
          guard let localUrl = localUrl else {
            completion(nil, NetworkManagerError.badLocalUrl)
            return
          }
          
          do {
            let data = try Data(contentsOf: localUrl)
            self.images.setObject(data as NSData, forKey: imageURL.absoluteString as NSString)
            completion(data, nil)
          } catch let error {
            completion(nil, error)
          }
        }
        
        task.resume()
      }
      
      func image(imageURL: String?, completion: @escaping (Data?, Error?) -> (Void)) {
        if let url = URL(string: imageURL ?? "") {
            download(imageURL: url, completion: completion)
        }
      }
    
}
