//
//  MovieModel.swift
//  SampleUnitTestApp
//
//  Created by Gowri Karthik on 06/06/21.
//

import Foundation

struct MovieCategory:Codable {
    var name: String?
    var movies: [Movie]?
    
    enum CodingKeys: String, CodingKey {
        case name = "name"
        case movies = "videos"
    }
}

struct Movie:Codable {
    var name: String?
    var image: String?
    var videoId: String?
    
    enum CodingKeys: String, CodingKey {
        case name = "name"
        case image = "image"
        case videoId = "videoId"
    }
}
