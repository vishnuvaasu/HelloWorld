//
//  NetworkError.swift
//  SampleUnitTestApp
//
//  Created by Gowri Karthik on 07/06/21.
//

import Foundation

enum NetworkError: LocalizedError, Equatable {
    case failedRequest(description: String)
    
    var errorDescription: String? {
        switch self {
            case .failedRequest(let des): return des
        }
    }
}
