//
//  SignInViewModelProtocol.swift
//  SampleUnitTestApp
//
//  Created by Gowri Karthik on 05/06/21.
//

import Foundation

protocol SignInViewModelProtocol {
    
    var isUserLogIn: Bool? { get set }
    
    init(delegate: SignViewModelDelegate, signInValidator: SignInValidatorProtocol)
    
    func signIn(email: String, password: String)
    func isUserLoggedIn() -> Bool
}
