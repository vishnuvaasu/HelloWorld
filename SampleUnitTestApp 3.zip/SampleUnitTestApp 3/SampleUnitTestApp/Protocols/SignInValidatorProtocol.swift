//
//  SignInValidatorProtocol.swift
//  SampleUnitTestApp
//
//  Created by Gowri Karthik on 05/06/21.
//

import Foundation

protocol SignInValidatorProtocol {
    func isValidEmail(_ email: String) -> Bool
    func isValidPassword(password: String) -> Bool
}
