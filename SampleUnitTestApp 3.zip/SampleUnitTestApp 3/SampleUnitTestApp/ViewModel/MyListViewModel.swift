////
////  MyListViewModel.swift
////  SampleUnitTestApp
////
////  Created by Gowri Karthik on 14/06/21.
////
//
//import UIKit
//
//class MyListViewModel {
//    
//    let realm = try! Realm()
//    
//    var movieData: Results<MoviesData>?
//    
//    var isAdded = false
//    
//    func fetchMyListData(_ videoId: String,completion:@escaping(_ success: Bool) -> Void) {
//        movieData = DatabaseManager.shared.fetch(object: MoviesData.self)
//        if let currentMovie = movieData?.filter("videoId == %@", videoId).first {
//            isAdded = currentMovie.done
//            completion(currentMovie.done)
//        } else {
//            completion(false)
//        }
//    }
//    
//    func addToMyList(_ movie:Movie?,_ categoryName:String, completion:@escaping(_ error: String?,_ success:Bool) -> Void) {
//        let newMovie = MoviesData()
//        newMovie.title = movie?.name ?? ""
//        newMovie.imageUrl = movie?.image ?? "image1"
//        newMovie.dateAdded = Date()
//        newMovie.category = categoryName
//        newMovie.videoId = movie?.videoId ?? ""
//        newMovie.done = true
//        DatabaseManager.shared.save(object: newMovie) { (error) in
//            if let err = error {
//                completion(err, false)
//                return
//            }
//            completion(nil, true)
//        }
//    }
//    
//    func deleteFromMyList(_ movie:Movie?,completion:@escaping(_ error: String?,_ success:Bool)->Void) {
//        if let currentMovie = movieData?.filter("videoId == %@", movie?.videoId ?? "").first {
//            DatabaseManager.shared.delete(object: currentMovie) { (error) in
//                if let err = error {
//                    completion(err, false)
//                    return
//                }
//                completion(nil, true)
//            }
//        }
//    }
//}
