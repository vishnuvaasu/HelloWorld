//
//  HomeViewModel.swift
//  SampleUnitTestApp
//
//  Created by Gowri Karthik on 06/06/21.
//

import Foundation
import UIKit

class HomeViewModel {
    
    private var baseService: BaseService!

    var noOfCategories = 0

    var movies: [MovieCategory] = [] {
        didSet {
            noOfCategories = movies.count
        }
    }
    
    init(baseService: BaseService = BaseService()) {
        self.baseService = baseService
    }
    
    func fetchMovies(completionCallBack: @escaping (String?, [MovieCategory]?) -> Void) {
        baseService.request(method: .get) { (err, data) in
            let decoder = JSONDecoder()
            do {
                if let json = data {
                    self.movies = try decoder.decode([MovieCategory].self, from: json.rawData(options: .prettyPrinted))
                    completionCallBack(nil, self.movies)
                } else {
                    completionCallBack(err, [])
                }
            } catch {
                completionCallBack(err, [])
            }
        }
    }

    func image(data: Data?) -> UIImage? {
        if let data = data {
            return UIImage(data: data)
        }
        return UIImage(named: "logo")
    }
    
    func fetchImage(imageURL: String,completion: @escaping (UIImage?) -> (Void)) {
        baseService.image(imageURL: imageURL) { (data, error) -> (Void) in
            let img = self.image(data: data)
            DispatchQueue.main.async {
                completion(img)
            }
        }
    }
    
    func getMovieCategory(index: Int) -> MovieCategory? {
        if index < noOfCategories {
            return movies[index]
        }
        return nil
    }
    
}
