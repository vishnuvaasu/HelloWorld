//
//  Constants.swift
//  SampleUnitTestApp
//
//  Created by Gowri Karthik on 06/06/21.
//

import Foundation

struct Constants {
    static let userLoginStatus = "UserLoginStatus"
    static let mainStoryboard = "Main"
    static let signInViewController = "SignInViewController"
    static let dashboardViewController = "DashboardViewController"
    static let movieDetailViewController = "MovieDetailViewController"
    static let categoryMovieListViewController = "CategoryMovieListViewController"
    static let dashboardNavigationController = "DashboardNavigationController"
    static let myListViewController = "MyListViewController"
    
    // Alert Related constants
    static let login = "Login"
    static let videos = "Videos"
    static let ok = "OK"
    static let myList = "MyList"
    static let edit = "Edit"
    static let done = "Done"
    static let errorTitle = "Error"
    
    // CollectionViewCell Size
    static let width = 120
    static let height = 150
    static let minMaxSpace = 10.0
    
    static let addImage = "baseline_add_white_24pt"
    static let doneImage = "baseline_done_white_24pt"
}
