//
//  SignInViewModelTests.swift
//  SampleUnitTestAppTests
//
//  Created by Gowri Karthik on 05/06/21.
//

import XCTest
@testable import SampleUnitTestApp

class SignInViewModelTests: XCTestCase {
    
    var sut: SignInViewModelProtocol!
    var mockSignViewModelDelegate: MockSignViewModelDelegate!
    var mockSignInValidator: MockSignInValidator!

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        mockSignViewModelDelegate = MockSignViewModelDelegate()
        mockSignInValidator = MockSignInValidator()
        sut = SignInViewModel(delegate: mockSignViewModelDelegate, signInValidator: mockSignInValidator)
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        sut = nil
        mockSignViewModelDelegate = nil
        mockSignInValidator = nil
    }
    
    // testSignInViewModel_WhenInfoProvided_ValidationShouldPass
    func testWhenInfoProvided() {
        mockSignInValidator.isEmailValidated = true
        mockSignInValidator.isPasswordValidated = true
        sut.signIn(email: "gowri@gmail.com", password: "Gowri@123")
                
        XCTAssertTrue(mockSignInValidator.isEmailValidated, "iSEmailValidated must be TRUE but returned FALSE")
        XCTAssertTrue(mockSignInValidator.isPasswordValidated, "isPasswordValidated must be TRUE but returned FALSE")
    }
    
    //testSignInViewModel_WhenLoginClick_successfullSignInIsCalled
    func testWhenLoginClick() {
        
        mockSignInValidator.isEmailValidated = true
        mockSignInValidator.isPasswordValidated = true
        
        sut.signIn(email: "gowri@gmail.com", password: "Gowri@123")
        XCTAssertTrue(mockSignViewModelDelegate.successIsCalled, "successIsCalled must be TRUE but returned FALSE")
    }
    
    //testSignInViewModel_WhenUserAlreadyLoggedIn_ShouldReturnTrue
    func testWhenUserAlreadyLoggedIn() {
        sut = MockSignInViewModel(delegate: mockSignViewModelDelegate, signInValidator: mockSignInValidator)
        sut.isUserLogIn = true
        XCTAssertTrue(sut.isUserLoggedIn(), "isUserLoggedIn() must return TRUE but returned FALSE")
        
    }
    
    //testSignInViewModel_WhenUserNotLoggedIn_ShouldReturnFalse
    func testWhenUserNotLoggedIn() {
        sut = MockSignInViewModel(delegate: mockSignViewModelDelegate, signInValidator: mockSignInValidator)
        sut.isUserLogIn = false
        XCTAssertFalse(sut.isUserLoggedIn(), "isUserLoggedIn() must return FALSE but returned TRUE")
    }
    
    //testSignInViewModel_WhenLoginClick_errorRecievedIsCalled
    func testErrorRecievedIsCalled() {
        
        mockSignInValidator.isEmailValidated = false
        mockSignInValidator.isPasswordValidated = false
        sut.signIn(email: "gowrigmail.com", password: "gowri123")
        
        XCTAssertTrue(mockSignViewModelDelegate.errorAlertRecieved, "errorAlertRecieved must be TRUE but returned FALSE")
    }
    
    //testSignInViewModel_WhenInfoProvided_EmailValidationShouldPassPasswordShouldFail
    func testEmailValidationShouldPass_PasswordShouldFail() {
        mockSignInValidator.isEmailValidated = true
        mockSignInValidator.isPasswordValidated = false
        sut.signIn(email: "gowri@gmail.com", password: "gowri123")
                
        XCTAssertTrue(mockSignInValidator.isEmailValidated, "iSEmailValidated must be TRUE but returned FALSE")
        XCTAssertFalse(mockSignInValidator.isPasswordValidated, "isPasswordValidated must be FALSE but returned TRUE")
    }
    
    // testSignInViewModel_WhenInfoProvided_EmailValidationShouldFailPasswordShouldPass
    func testEmailValidationShouldFail_PasswordShouldPass() {
        mockSignInValidator.isEmailValidated = false
        mockSignInValidator.isPasswordValidated = true
        sut.signIn(email: "gowrigmail.com", password: "Gowri123@")
                
        XCTAssertFalse(mockSignInValidator.isEmailValidated, "iSEmailValidated must be TRUE but returned FALSE")
        XCTAssertTrue(mockSignInValidator.isPasswordValidated, "isPasswordValidated must be FALSE but returned TRUE")
    }

}
