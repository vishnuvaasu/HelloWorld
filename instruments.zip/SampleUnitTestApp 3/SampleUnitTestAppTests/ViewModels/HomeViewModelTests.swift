//
//  HomeViewModelTests.swift
//  SampleUnitTestAppTests
//
//  Created by Gowri Karthik on 06/06/21.
//

import XCTest
@testable import SampleUnitTestApp

class HomeViewModelTests: XCTestCase {
    
    var viewModel: HomeViewModel!
    
    override func setUpWithError() throws {
    // By providing a custom protocol to the iOS URL loading system, we can intercept the network communication and make sure certain URL requests are given a special treatment.
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [MockURLProtocol.self]
        let urlSession = URLSession(configuration: config)
        
        let baseService = BaseService(urlSession: urlSession)
        
        viewModel = HomeViewModel(baseService: baseService)
    }
    
    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        viewModel = nil
    }
    
    //test HomeViewModel_WhenFetchMovies Success Result Should Be MoviesCategory Array
    func testFetchMoviesResult() throws {
        
        guard let pathString = Bundle(for: type(of: self)).path(forResource: "SampleMovie", ofType: "json") else {
            fatalError("SampleMovie.json not found")
        }
         let data = try? Data(contentsOf: URL(fileURLWithPath: pathString))
        MockURLProtocol.stubResponseData = data
        MockURLProtocol.error = nil
        
   //     let myExpectation = expectation(description: "An Array of Movies Category")
        
        viewModel.fetchMovies { (error, movieCategories) in
            XCTAssertNil(error)
            XCTAssertEqual(movieCategories?.count, 6, "Expected to received an Array of Movie categories but response json is not as expected")
            let firstCategory = movieCategories?.first
            
            XCTAssertEqual(firstCategory?.name, "Trending", "Name of category must be Treanding")
            
  //          myExpectation.fulfill()
        }
        
   //     wait(for: [myExpectation], timeout: 2)
    }
    
    func testFetchMovies_shouldReturnError() {
        MockURLProtocol.stubResponseData = nil
        MockURLProtocol.error = NetworkError.failedRequest(description: "Invalid Data")
                
        viewModel.fetchMovies { (error, movieCategories) in
            XCTAssertTrue(error != nil )
        }
    }
    
    //this should pass so that we can know that we got an error in decoding
    func testFetchMovies_jSonDecodeError() throws{
        let dic = [
            [
                "name": 1,
            ]
        ]
        MockURLProtocol.stubResponseData = try JSONSerialization.data(withJSONObject: dic, options: .prettyPrinted)
        MockURLProtocol.error = nil
        viewModel.fetchMovies { (error, movieCategories) in
            XCTAssertEqual(movieCategories?.count, 0)
        }
    }
    
    func testMovieCategoryShouldReturn() {
        let movies = [Movie(name: "Jumaji", image: "https://i.ytimg.com/vi/MJuFdpVCcsY/movieposter_en.jpg")]
        viewModel.movies = [MovieCategory(name: "Trending", movies: movies)]
        
        let movie = viewModel.getMovieCategory(index: 0)
        
        XCTAssertNotNil(movie)
    
    }
    
    func testHomeViewModelIndexOutOfBound() {
        let movies = [Movie(name: "Jumaji", image: "https://i.ytimg.com/vi/MJuFdpVCcsY/movieposter_en.jpg")]
        viewModel.movies = [MovieCategory(name: "Trending", movies: movies)]
        
        let movie = viewModel.getMovieCategory(index: 3)
        
        XCTAssertNil(movie)
    
    }

}
