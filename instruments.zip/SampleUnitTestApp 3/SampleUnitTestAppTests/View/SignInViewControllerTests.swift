//
//  SignInViewControllerTests.swift
//  SampleUnitTestAppTests
//
//  Created by Gowri Karthik on 04/06/21.
//

import XCTest
@testable import SampleUnitTestApp

class SignInViewControllerTests: XCTestCase {

    var storyboard: UIStoryboard!
    var sut: SignInViewController!
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        storyboard = UIStoryboard(name: Constants.mainStoryboard, bundle: nil)
        sut = storyboard.instantiateViewController(identifier: Constants.signInViewController) as SignInViewController
        sut.loadViewIfNeeded()
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        storyboard = nil
        sut = nil
    }
    
    // testSignInViewController_WhenCreated_requiredDefaultTextFieldSetup
    func testRequiredDefaultTextFieldSetup() throws {
        let emailTextField = try XCTUnwrap(sut.emailTextField, "emailTextField is not connected to an Outlet")
        let passwordTextField = try XCTUnwrap(sut.passwordTextField, "passwordTextField is not connected to an Outlet")
        
        XCTAssertEqual(emailTextField.text, "", "emailTextField is not empty when the viewcontroller was initially loaded")
        XCTAssertEqual(emailTextField.keyboardType, .emailAddress, "emailTextField keyboard type must be Email Address")
        XCTAssertEqual(emailTextField.textContentType, .emailAddress, "emailTextField content type must be Email Address")
        
        XCTAssertEqual(passwordTextField.text, "", "passwordTextField is not empty when the viewcontroller was initially loaded")
        XCTAssertEqual(passwordTextField.textContentType, .password, "passwordTextField content type must be password")
        XCTAssertTrue(passwordTextField.isSecureTextEntry)
    }
    
    // testSignInViewController_WhenCreated_hasLoginButtonAndAction
    func testHasLoginButtonAndAction() throws {
        // Arrange
        let loginButton: UIButton = try XCTUnwrap(sut.loginButton, "loginButton is not connected to an Outlet")
        
        //Act
        let loginButtonAction = try XCTUnwrap(loginButton.actions(forTarget: sut, forControlEvent: .touchUpInside), "Login button action is not assigned")
        
        //Assert
        XCTAssertEqual(loginButtonAction.count, 1)
        XCTAssertEqual(loginButtonAction.first, "loginClick:", "There is no action with a name loginClick assigned to login button")
    }
    
    // testSignInViewController_LoginClick_successfulSignInCalled
    func testSuccessfulSignInCalled() {
        
        let mockSignInViewModel = MockSignInViewModel(delegate: MockSignViewModelDelegate(), signInValidator: MockSignInValidator())
        
        sut.viewModel = mockSignInViewModel
    
        sut.loginButton.sendActions(for: .touchUpInside)
                
        XCTAssertTrue(mockSignInViewModel.isSignInMethodCalled, "When click login isSignInMethodCalled should be TRUE but False is Returned")
    }
    
    // testSignInViewController_WhenUserNotLoggedIn_topViewControllerIsSignInViewController
    func testWhenUserNotLoggedIn() throws {
        let mockSignInViewModel = MockSignInViewModel(delegate: MockSignViewModelDelegate(), signInValidator: MockSignInValidator())
        
        sut.viewModel = mockSignInViewModel
        mockSignInViewModel.isUserLogIn = false
        
        let topViewController = try XCTUnwrap(UIApplication.shared.windows.first?.rootViewController, "Root ViewController is not set yet")
        XCTAssertTrue(topViewController is SignInViewController, "Top ViewController must be SignInViewController")
    }
    
    // testSignInViewController_WhenUserLoggedIn_topViewControllerIsDashboardNavigationController
    func testWhenUserLoggedIn() throws {
        let mockSignInViewModel = MockSignInViewModel(delegate: MockSignViewModelDelegate(), signInValidator: MockSignInValidator())
        
        sut.viewModel = mockSignInViewModel
        mockSignInViewModel.isUserLogIn = true
        
        //TODO: Need to check whether Dashboard is Presented or Not
    }
    
    // testSignInViewController_WhenCreated_otherOutletsAreConnected
    func testOtherOutletsAreConnected() throws {
        let _ = try XCTUnwrap(sut.logoImageView, "logoImageView is not connected to an Outlet")        
        let _ = try XCTUnwrap(sut.cardView, "cardView is not connected to an Outlet")
    }

}
