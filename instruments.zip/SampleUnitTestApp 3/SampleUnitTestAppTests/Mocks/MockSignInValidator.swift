//
//  MockSignInValidator.swift
//  SampleUnitTestAppTests
//
//  Created by Gowri Karthik on 05/06/21.
//

import Foundation
@testable import SampleUnitTestApp

class MockSignInValidator: SignInValidatorProtocol {
    
    var isEmailValidated: Bool = false
    var isPasswordValidated: Bool = false
    
    func isValidEmail(_ email: String) -> Bool {
        return isEmailValidated
    }
    
    func isValidPassword(password: String) -> Bool {
        return isPasswordValidated
    }
    
    
}
