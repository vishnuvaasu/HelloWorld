//
//  MockSignViewModelDelegate.swift
//  SampleUnitTestAppTests
//
//  Created by Gowri Karthik on 05/06/21.
//

import XCTest
@testable import SampleUnitTestApp

class MockSignViewModelDelegate: SignViewModelDelegate {
    
    var errorAlertRecieved = false
    var successIsCalled = false
    
    func onErrorReceived(error: SignInError) {
        errorAlertRecieved = true
    }
    
    func onSuccessfullSignIn() {
        successIsCalled = true
    }
}
