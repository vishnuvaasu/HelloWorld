//
//  SignInValidatorTests.swift
//  SampleUnitTestAppTests
//
//  Created by Gowri Karthik on 05/06/21.
//

import XCTest
@testable import SampleUnitTestApp

class SignInValidatorTests: XCTestCase {
    
    var sut: SignInValidator!

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        sut = SignInValidator()
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        sut = nil
    }
    
    // testSignInValidator_WhenValidEmailProvided_shouldReturnTrue
    func testValidEmailProvided() {
        XCTAssertTrue(sut.isValidEmail("gowri@gmail.com"), "The isValidEmail() method should return TRUE for a valid email but returned FALSE")
    }
    
    // testSignInValidator_WhenInValidEmailProvided_shouldReturnFalse
    func testInvalidEmailProvided() {
        XCTAssertFalse(sut.isValidEmail("gowri@gmail"), "The isValidEmail() method should return FALSE for a invalid email but returned TRUE")
    }
    
    // testSignInValidator_WhenValidPasswordProvided_ShouldReturnTrue
    func testValidPasswordProvided() {
        XCTAssertTrue(sut.isValidPassword(password: "Gowri@123"), "The isValidPassword() method should return TRUE for a valid email but returned FALSE")
    }
    
    // testSignInValidator_WhenInValidPasswordProvided_ShouldReturnFalse
    func testInvalidPasswordProvided() {
        XCTAssertFalse(sut.isValidPassword(password: "gowri123"), "The isValidPassword() method should return FALSE for a valid email but returned TRUE")
    }

}
