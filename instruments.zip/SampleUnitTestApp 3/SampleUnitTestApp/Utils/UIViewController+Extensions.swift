//
//  UIViewController+Extensions.swift
//  SampleTask
//
//  Created by Gowri Karthik on 12/06/21.
//

import UIKit

extension UIViewController {
    
    func showAlert(title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: Constants.ok, style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
    
}
