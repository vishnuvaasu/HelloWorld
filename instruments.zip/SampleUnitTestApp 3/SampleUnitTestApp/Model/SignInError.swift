//
//  SignInError.swift
//  SampleUnitTestApp
//
//  Created by Gowri Karthik on 05/06/21.
//

import Foundation

enum SignInError: LocalizedError {
    case inValidEmail
    case inValidPassword
    
    var errorDescription: String? {
        switch self {
        case .inValidEmail: return "Email is invalid"
        case .inValidPassword: return "Password is invalid"
        }
    }
}
