////
////  DatabaseManager.swift
////  SampleUnitTestApp
////
////  Created by Gowri Karthik on 14/06/21.
////
//
//import RealmSwift
//
//class DatabaseManager
//{
//    let realm = try! Realm()
//    // MARK:- Data Manupulation
//    
//    static let shared = DatabaseManager()
//    
//    func fetch<T: Object>(object: T.Type) -> Results<T> {
//        return realm.objects(object.self)
//    }
//    
//    func save<T: Object>(object: T, completion:@escaping(_ error: String?) -> Void) {
//        do {
//            try realm.write({
//                realm.add(object)
//                completion(nil)
//            })
//        } catch {
//            completion("Failed to save in db: \(error.localizedDescription)")
//        }
//    }
//    
//    
//    func delete<T:Object>(object: T, completion:@escaping(_ error: String?) -> Void) {
//        do {
//            try realm.write({
//                realm.delete(object)
//                completion(nil)
//            })
//        } catch {
//            print(error)
//            completion("Failed to delete in db: \(error.localizedDescription)")
//        }
//    }
//}
