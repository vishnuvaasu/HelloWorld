//
//  SignInViewModel.swift
//  SampleUnitTestApp
//
//  Created by Gowri Karthik on 05/06/21.
//

import UIKit

class SignInViewModel: SignInViewModelProtocol {
    
    var isUserLogIn: Bool?
    
    private weak var delegate: SignViewModelDelegate?
    private let signInValidator: SignInValidatorProtocol!
    
    required init(delegate: SignViewModelDelegate, signInValidator: SignInValidatorProtocol) {
        self.delegate = delegate
        self.signInValidator = signInValidator
    }
    
    func isUserLoggedIn() -> Bool {
        return UserDefaults.standard.object(forKey: Constants.userLoginStatus) as? Bool ?? false
    }
    
    func signIn(email: String, password: String) {
        if !signInValidator.isValidEmail(email) {
            delegate?.onErrorReceived(error: .inValidEmail)
            return
        }
        
        if !signInValidator.isValidPassword(password: password) {
            delegate?.onErrorReceived(error: .inValidPassword)
            return
        }
        UserDefaults.standard.setValue(true, forKey: Constants.userLoginStatus)
        delegate?.onSuccessfullSignIn()
    }
    
}
