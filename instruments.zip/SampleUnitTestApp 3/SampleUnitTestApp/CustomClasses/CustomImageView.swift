////
////  CustomImageView.swift
////  LazyLoadingWithTestCase
////
////  Created by Gowri Karthik on 02/06/21.
////
//
//import UIKit
//
//let imageCache = NSCache< NSString, AnyObject>()
//class CustomImageView: UIImageView {
//    
//    var imageUrlString :String?
//    
//    func loadImageUsingURLString(urlString:String) {
//        imageUrlString = urlString
//        image = nil
//        if let imageFromCache = imageCache.object(forKey: urlString as NSString ) as? UIImage{
//            self.image = self.decodeImage(image: imageFromCache )
//            return
//        }
//
//        if let url = URL(string: urlString) {
//            let task = URLSession.shared.dataTask(with: url) { data, response, error in
//                guard let data = data, error == nil else {
//                    print(error.debugDescription)
//                    return
//                }
//               let imageToCache = self.decodeImage(image: UIImage(data: data) ?? UIImage(named: "logo")!)
//                //let imageToCache =  UIImage(data: data) ?? UIImage(named: "logo")!
//                DispatchQueue.main.async { 
//
//                    if self.imageUrlString == urlString{
//                        //self.image = imageToCache
//                        self.layer.contents = imageToCache?.cgImage
//                    }
//                    if imageToCache != nil {
//                        imageCache.setObject(imageToCache!, forKey: urlString as NSString)
//                    }
//
//                }
//            }
//
//            task.resume()
//        }
//    }
//    
//    func decodeImage(image:UIImage) -> UIImage?{
//        guard let newImage  =  image.cgImage else {return nil}
//        
//        let colorSpace = CGColorSpaceCreateDeviceRGB()
//        let context = CGContext(data: nil, width: newImage.width, height: newImage.height, bitsPerComponent: 8, bytesPerRow: newImage.width * 4, space: colorSpace, bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue)
//        context?.draw(newImage, in: CGRect(x: 0, y: 0, width: newImage.width, height: newImage.height))
//        let decodedImge = context?.makeImage()
//        if let decodedImage = decodedImge{
//            return UIImage(cgImage: decodedImage)
//        }
//        return nil
//    }
//    
////    func loadImageUsingURLString(urlString:String) {
////        if let url = URL(string: urlString) {
////            let data = try? Data(contentsOf: url)
////
////            if let imageData = data {
////                self.image = UIImage(data: imageData)
////            }
////        }
////    }
//    
//    
//}
// 
