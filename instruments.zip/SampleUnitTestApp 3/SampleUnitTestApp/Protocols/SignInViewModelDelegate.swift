//
//  SignInViewModelDelegate.swift
//  SampleUnitTestApp
//
//  Created by Gowri Karthik on 05/06/21.
//

import Foundation

protocol SignViewModelDelegate: AnyObject {
    func onErrorReceived(error: SignInError)
    func onSuccessfullSignIn()
}
