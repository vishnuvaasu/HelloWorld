//
//  MovieDetailViewController.swift
//  LazyLoadingWithTestCase
//
//  Created by Gowri Karthik on 31/05/21.
//

import UIKit

class MovieDetailViewController: UIViewController {

    @IBOutlet weak var movieImageView: AsyncImageView!
    @IBOutlet weak var movieName: UILabel!
    @IBOutlet weak var addButton: UIButton!
    
    var viewModel = HomeViewModel()
    var movie: Movie?
    var categoryName =  ""
    
  //  var myListViewModel =  MyListViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        movieImageView.loadImageUsingURLString(urlString: movie?.image ?? "image1")
        movieName.text = movie?.name
        title = movie?.name
    }
    
    

}
